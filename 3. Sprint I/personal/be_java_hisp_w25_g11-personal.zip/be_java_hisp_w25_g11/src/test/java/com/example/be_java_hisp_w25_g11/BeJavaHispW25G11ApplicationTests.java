package com.example.be_java_hisp_w25_g11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeJavaHispW25G11ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.be_java_hisp_w25_g11.repository.seller_post;

import com.example.be_java_hisp_w25_g11.entity.SellerPost;
import com.example.be_java_hisp_w25_g11.repository.ICrudRepository;

public interface ISellerPostRepository extends ICrudRepository <SellerPost, Integer> {  }

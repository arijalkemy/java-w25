package com.example.be_java_hisp_w25_g11.repository.buyer;

import com.example.be_java_hisp_w25_g11.entity.Buyer;
import com.example.be_java_hisp_w25_g11.repository.ICrudRepository;

public interface IBuyerRepository extends ICrudRepository <Buyer, Integer> { }

package com.example.be_java_hisp_w25_g11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeJavaHispW25G11Application {
	public static void main(String[] args) {
		SpringApplication.run(BeJavaHispW25G11Application.class, args);
	}
}

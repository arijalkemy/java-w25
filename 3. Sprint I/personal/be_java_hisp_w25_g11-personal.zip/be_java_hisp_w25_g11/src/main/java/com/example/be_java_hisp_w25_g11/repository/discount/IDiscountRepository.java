package com.example.be_java_hisp_w25_g11.repository.discount;

import com.example.be_java_hisp_w25_g11.entity.Discount;
import com.example.be_java_hisp_w25_g11.repository.ICrudRepository;

public interface IDiscountRepository extends ICrudRepository<Discount,Integer> {
}

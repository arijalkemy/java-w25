package com.example.be_java_hisp_w25_g11.exception;

public class NotFoundException extends RuntimeException{

    public NotFoundException (String message) {
        super(message);
    }
}

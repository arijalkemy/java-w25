package com.socialMeli.entity;

public enum UserType {
    CLIENT, VENDOR
}

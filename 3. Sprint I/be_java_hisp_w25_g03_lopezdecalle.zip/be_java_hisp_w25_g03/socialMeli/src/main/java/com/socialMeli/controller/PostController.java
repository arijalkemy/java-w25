package com.socialMeli.controller;

import com.socialMeli.dto.request.PostDTO;
import com.socialMeli.dto.response.MessageDTO;
import com.socialMeli.dto.response.PromoPublicationDto;
import com.socialMeli.dto.response.PublicationDto;
import com.socialMeli.dto.response.VendorPromoPostCountDto;
import com.socialMeli.service.IPostService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
public class PostController {

    private final IPostService postService;


    @GetMapping("/products/followed/{userId}/list")
    public ResponseEntity<PublicationDto> obtainLastPublicationsByTheFollowedVendors(
                                                            @PathVariable Integer userId,
                                                            @RequestParam(required = false) String order) {
        return ResponseEntity.ok().body(postService.obtainLastPublicationsByTheFollowedVendors(userId, order));
    }

    @PostMapping("/products/post")
    public ResponseEntity<MessageDTO> addNewPost(@RequestBody PostDTO postDto){
        postService.addPost(postDto);
        return new ResponseEntity<>(new MessageDTO("Post creado con éxito"), HttpStatus.OK);
    }

    @PostMapping("/products/promo-post")
    public ResponseEntity<MessageDTO> addNewPromoPost(@RequestBody PostDTO postDTO){
        postService.addPost(postDTO);
        return new ResponseEntity<>(new MessageDTO("Promo post creado con éxito"), HttpStatus.OK);
    }

    @GetMapping("/products/promo-post/count")
    public ResponseEntity<VendorPromoPostCountDto> obtainVendorPromoPostCount(@RequestParam(required = true) Integer user_id){
        return new ResponseEntity<>(postService.obtainCountPromoPostFromVendor(user_id), HttpStatus.OK);
    }

    @GetMapping("/products/promo-post/list")
    public ResponseEntity<PromoPublicationDto> obtainVendorPromoPostList(@RequestParam(required = true) Integer user_id){
        return new ResponseEntity<>(postService.obtainListPromoPostFromVendor(user_id), HttpStatus.OK);
    }
}

package com.socialMeli.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.socialMeli.dto.request.PostDTO;
import com.socialMeli.entity.User;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class VendorPromoPostCountDto {
    @JsonProperty("user_id")
    Integer userId;
    @JsonProperty("user_name")
    String userName;
    @JsonProperty("promo_products_count")
    Integer promoProductsCount;

    public VendorPromoPostCountDto(User user, Integer promoProductsCount) {
        this.userId = user.getId();
        this.userName = user.getName();
        this.promoProductsCount = promoProductsCount;
    }
}

package com.socialMeli.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.socialMeli.entity.User;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
public class PromoPublicationDto {
    @JsonProperty("user_id")
    Integer userId;
    @JsonProperty("user_name")
    String name;
    @JsonProperty("posts")
    List<PostDto> postDTOList;

    public PromoPublicationDto(User user, List<PostDto> postDTOList) {
        this.userId = user.getId();
        this.name = user.getName();
        this.postDTOList = postDTOList;
    }
}

package com.socialMeli.service;

import com.socialMeli.dto.response.PromoPublicationDto;
import com.socialMeli.dto.response.PublicationDto;

import com.socialMeli.dto.request.PostDTO;
import com.socialMeli.dto.response.VendorPromoPostCountDto;


public interface IPostService {

    PublicationDto obtainLastPublicationsByTheFollowedVendors(Integer userId, String order);
    void addPost(PostDTO post);

    VendorPromoPostCountDto obtainCountPromoPostFromVendor(Integer userId);

    PromoPublicationDto obtainListPromoPostFromVendor(Integer userId);
}

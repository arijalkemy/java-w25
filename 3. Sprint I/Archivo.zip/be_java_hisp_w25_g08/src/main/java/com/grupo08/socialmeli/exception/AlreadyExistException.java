package com.grupo08.socialmeli.exception;

public class AlreadyExistException extends RuntimeException{
    public AlreadyExistException(String message){ super(message); }
}

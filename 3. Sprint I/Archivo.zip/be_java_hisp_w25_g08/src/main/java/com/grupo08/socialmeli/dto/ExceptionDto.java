package com.grupo08.socialmeli.dto;

public record ExceptionDto (String message){
}

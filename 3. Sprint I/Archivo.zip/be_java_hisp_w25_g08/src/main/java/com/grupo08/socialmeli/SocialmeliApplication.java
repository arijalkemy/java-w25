package com.grupo08.socialmeli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialmeliApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialmeliApplication.class, args);
	}

}

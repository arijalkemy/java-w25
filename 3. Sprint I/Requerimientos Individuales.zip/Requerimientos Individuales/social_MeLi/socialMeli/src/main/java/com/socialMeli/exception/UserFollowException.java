package com.socialMeli.exception;

public class UserFollowException extends RuntimeException {
    public UserFollowException(String s) {
        super(s);
    }
}

package com.socialMeli.exception;

public class UserIsNotVendorException extends RuntimeException {
    public UserIsNotVendorException(String s) {
        super(s);
    }
}

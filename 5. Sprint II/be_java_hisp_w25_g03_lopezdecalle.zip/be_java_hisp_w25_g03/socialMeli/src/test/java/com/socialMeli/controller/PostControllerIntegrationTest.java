package com.socialMeli.controller;

import com.socialMeli.dto.response.MessageDto;
import com.socialMeli.repository.PostRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class PostControllerIntegrationTest {
    @Autowired
    MockMvc mockMvc;
    @Test
    void addNewPostOk() throws Exception{
        MessageDto expectedMessage = new MessageDto("Post creado con éxito");
        String request = "{\n" +
                "    \"user_id\": 8,\n" +
                "    \"date\": \"14-02-2024\",\n" +
                "    \"product\": {\n" +
                "        \"product_id\": 1,\n" +
                "        \"product_name\": \"Silla Gamer\",\n" +
                "        \"type\": \"Gamer\",\n" +
                "        \"brand\": \"Racer\",\n" +
                "        \"color\": \"Black\",\n" +
                "        \"notes\": \"Special Edition\"\n" +
                "    },\n" +
                "    \"category\": 100,\n" +
                "    \"price\": 1500.50\n" +
                "}";
        mockMvc.perform(post("/products/post")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(request))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.message").value(expectedMessage.getMessage()));
    }

    @Test
    void addNewPostUserNotVendor() throws Exception{
        String request = "{\n" +
                "    \"user_id\": 1,\n" +
                "    \"date\": \"14-02-2024\",\n" +
                "    \"product\": {\n" +
                "        \"product_id\": 1,\n" +
                "        \"product_name\": \"Silla Gamer\",\n" +
                "        \"type\": \"Gamer\",\n" +
                "        \"brand\": \"Racer\",\n" +
                "        \"color\": \"Black\",\n" +
                "        \"notes\": \"Special Edition\"\n" +
                "    },\n" +
                "    \"category\": 100,\n" +
                "    \"price\": 1500.50\n" +
                "}";
        mockMvc.perform(post("/products/post")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(request))
                .andDo(print())
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType("application/json"))
                .andExpect(jsonPath("$.message").value("El usuario Luciano Gonzalez no es un vendedor"));
    }

    @Test
    void addNewPostError() throws Exception{
        String request = "{\n" +
                "    \"user_id\": -1,\n" +
                "    \"date\": \"\",\n" +
                "    \"product\": {\n" +
                "        \"product_id\": -1,\n" +
                "        \"product_name\": \"$@\",\n" +
                "        \"type\": \"aaaaaaaaaaaaaaaa\",\n" +
                "        \"brand\": \"@@\",\n" +
                "        \"color\": \"@@\",\n" +
                "        \"notes\": \"@@\"\n" +
                "    },\n" +
                "    \"category\":\"\",\n" +
                "    \"price\": 1000000000.50\n" +
                "}";
        String expectedResponse = "{\n" +
                "    \"product.id\": \"El id debe ser un valor positivo\",\n" +
                "    \"product.name\": \"La cadena no es válida\",\n" +
                "    \"product.type\": \"La longitud no puede superar los 15 caracteres\",\n" +
                "    \"product.brand\": \"La cadena no es válida\",\n" +
                "    \"product.color\": \"La cadena no es válida\",\n" +
                "    \"product.note\": \"La cadena no es válida\",\n" +
                "    \"date\": \"La fecha no puede estar vacia\",\n" +
                "    \"category\": \"La categoria no puede estar vacia\",\n" +
                "    \"price\": \"El valor supera el valor maximo aceptado(10millones)\",\n" +
                "    \"userId\": \"El id debe ser un valor positivo\"\n" +
                "}";
         mockMvc.perform(post("/products/post")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(request))
                .andDo(print())
                 .andExpect(content().contentType("application/json"))
                .andExpect(status().isBadRequest())
                .andExpect(content().json(expectedResponse));

    }

    @Test
    void obtainLastPublicationsByTheFollowedVendorsOk() throws Exception{
        mockMvc.perform(get("/products/followed/{userId}/list", 8))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.user_id").value(8));

    }

    @Test
    void obtainLastPublicationsByTheFollowedVendorsError() throws Exception{
        mockMvc.perform(get("/products/followed/{userId}/list", 111))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("No se encontro al usuario"));

    }


}

package com.socialMeli.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestClassOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;

import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class UserControllerIntegrationTest {
    @Autowired
    MockMvc mockMvc;

    @Test
    void getVendorFollowersOk() throws Exception {
        String expectedResponse = "{\n" +
                "    \"user_id\": 8,\n" +
                "    \"user_name\": \"Valeria Ramirez\",\n" +
                "    \"followed\": [\n" +
                "        {\n" +
                "            \"user_id\": 1,\n" +
                "            \"user_name\": \"Luciano Gonzalez\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"user_id\": 2,\n" +
                "            \"user_name\": \"Sofia Fernandez\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        mockMvc.perform(get("/users/{userId}/followers/list", 8))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(content().json(expectedResponse));
    }

    @Test
    void getVendorFollowersUserNotVendor() throws Exception {
        mockMvc.perform(get("/users/{userId}/followers/list", 1))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value("El usuario no es un vendedor"));
    }

    @Test
    void getVendorFollowersInvalidId() throws Exception {
        mockMvc.perform(get("/users/{userId}/followers/list", -1))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.userId").value("El id debe ser un valor positivo"));
    }

    @Test
    void getFollowerCountOk() throws Exception{
        mockMvc.perform(get("/users/{userId}/followers/count", 8))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.followers_count").value(2));
    }

    @Test
    void getFollowerCountUserNotVendor() throws Exception {
        mockMvc.perform(get("/users/{userId}/followers/count", 1))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value("El usuario no es un vendedor"));
    }

    @Test
    void getFollowerCountUserNull() throws Exception {
        mockMvc.perform(get("/users/{userId}/followers/list", -1))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.userId").value("El id debe ser un valor positivo"));
    }

    @Test
    void getFollowedListOk() throws Exception {
        String expectedResponse = "{\n" +
                "    \"user_id\": 1,\n" +
                "    \"user_name\": \"Luciano Gonzalez\",\n" +
                "    \"followed\": [\n" +
                "        {\n" +
                "            \"user_id\": 8,\n" +
                "            \"user_name\": \"Valeria Ramirez\"\n" +
                "        },\n" +
                "        {\n" +
                "            \"user_id\": 10,\n" +
                "            \"user_name\": \"Victoria Acosta\"\n" +
                "        }\n" +
                "    ]\n" +
                "}";
        mockMvc.perform(get("/users/{userId}/followed/list", 1))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(content().json(expectedResponse));
    }

    @Test
    void getFollowedListUserNotFound() throws Exception {
        mockMvc.perform(get("/users/{userId}/followed/list", 111))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("No se encontro al usuario"));
    }

    @Test
    void followOk() throws Exception {
        mockMvc.perform(post("/users/{userId}/follow/{userIdToFollow}", 3, 9))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Comenzaste a seguir al usuario Tomas Castro"));
    }

    @Test
    void followUserFollowException() throws Exception {
        mockMvc.perform(post("/users/{userId}/follow/{userIdToFollow}", 1, 8))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value("Ya sigues a este usuario"));
    }

    @Test
    void followInvalidsUsersIds() throws Exception {
        mockMvc.perform(post("/users/{userId}/follow/{userIdToFollow}", -1, -8))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.userId").value("El id debe ser un valor positivo"))
                .andExpect(jsonPath("$.userIdToFollow").value("El id debe ser un valor positivo"));
    }

    @Test
    void unfollowUserOk() throws Exception {
        mockMvc.perform(post("/users/{userId}/unfollow/{userIdToFollow}", 3, 9))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Dejaste de seguir a Tomas Castro"));
    }

    @Test
    void unfollowUserNotFollowed() throws Exception {
        mockMvc.perform(post("/users/{userId}/unfollow/{userIdToFollow}", 3, 8))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isForbidden())
                .andExpect(jsonPath("$.message").value("El usuario no esta en tu lista de followed"));
    }

    @Test
    void unfollowUsersIdsNotValid() throws Exception {
        mockMvc.perform(post("/users/{userId}/unfollow/{userIdToFollow}", -3, -8))
                .andDo(print())
                .andExpect(content().contentType("application/json"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.userId").value("El id debe ser un valor positivo"))
                .andExpect(jsonPath("$.userIdToUnfollow").value("El id debe ser un valor positivo"));
    }


}

package com.socialMeli.dto.response;

public record UserUnfollowedDto(Integer userId,Integer userIdToUnfollow) {

}

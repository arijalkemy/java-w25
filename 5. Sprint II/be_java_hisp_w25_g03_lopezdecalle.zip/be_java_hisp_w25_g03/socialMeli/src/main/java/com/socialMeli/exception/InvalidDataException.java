package com.socialMeli.exception;

public class InvalidDataException extends IllegalArgumentException{
    public InvalidDataException(String s) {
        super(s);
    }
}

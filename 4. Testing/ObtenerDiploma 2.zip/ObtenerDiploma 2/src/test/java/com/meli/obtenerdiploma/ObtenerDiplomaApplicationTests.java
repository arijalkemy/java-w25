package com.meli.obtenerdiploma;

import com.meli.obtenerdiploma.exception.StudentNotFoundException;
import com.meli.obtenerdiploma.model.StudentDTO;
import com.meli.obtenerdiploma.repository.StudentDAO;
import com.meli.obtenerdiploma.service.ObtenerDiplomaService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import utils.FactoryStudent;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class ObetenerDiplomaApplicationTests {

	FactoryStudent f = new FactoryStudent();
	@Mock // No se pueden poner varios mocks, pero si varios inject Mocks
	StudentDAO studentDAO;

	@InjectMocks
	private ObtenerDiplomaService obtenerDiplomaService;  // Tincho dijo q es mejor poner la clase directamente para evitar poner el contexto

	@Test
	public void analyzeScoresTestOK () {
		// Arrange
		FactoryStudent f = new FactoryStudent();
		StudentDTO studentBase = f.getStudent();
		StudentDTO studentExpected = f.getStudentObtenerDiplomaExpectedTest();
		// Verify es solo por si el metodo devuelve void, para saber si lo hizo o no
		when(studentDAO.findById(anyLong())).thenReturn(studentBase);
		// Act
		StudentDTO studentDTOresponse = obtenerDiplomaService.analyzeScores(anyLong());
		// Assert
		assertEquals(studentExpected, studentDTOresponse);
	}

	// StudentNotFoundException

	@Test // Duda
	public void analyzeScoresTestThrowableStudentNotFound () {
		// Arrange
		StudentDTO studentBase = f.getStudent();
		StudentDTO studentExpected = f.getStudentObtenerDiplomaExpectedTest();
		// Verify es solo por si el metodo devuelve void, para saber si lo hizo o no
		studentDAO.findById(-1L); // Duda
		// Act
		StudentDTO studentDTOresponse = obtenerDiplomaService.analyzeScores(anyLong());
		// Assert
		assertEquals(studentExpected, studentDTOresponse);
	}


	/*

	Casos nulos, vacíos, inválidos.
	Datos de Salida idénticos a datos de Entrada.
	Cálculo del Promedio	.
	Leyenda del Diploma.
	Mensaje de Diploma con Honores.


	Pasos del test Unitario con Mocks:

	- Crear el mock IStudentDAO.
	- Inyectarlo en ObtenerDiplomaService.
	- Configurar su comportamiento (setup) con el método when.
	- Realizar el test con un nombre de los casos borde, usar los asserts correspondientes.
	 */
}
package com.meli.obtenerdiploma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObtenerDiplomaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObtenerDiplomaApplication.class, args);
	}

}

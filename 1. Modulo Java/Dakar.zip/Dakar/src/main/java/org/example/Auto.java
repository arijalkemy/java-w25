package org.example;

public class Auto extends Vehiculo{

    public Auto() {
    }

    public Auto(double velocidad, double aceleracion, double anguloGiro, String patente, double peso, int ruedas) {
        super(velocidad, aceleracion, anguloGiro, patente, peso, ruedas);
    }


}

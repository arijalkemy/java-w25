package com.crud.crud_con_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudConJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.ejercicio_obras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioObrasApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioObrasApplication.class, args);
	}

}

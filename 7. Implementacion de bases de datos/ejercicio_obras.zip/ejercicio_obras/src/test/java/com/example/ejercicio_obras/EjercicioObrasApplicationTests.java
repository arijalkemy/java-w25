package com.example.ejercicio_obras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioObrasApplicationTests {

	@Test
	void contextLoads() {
	}

}

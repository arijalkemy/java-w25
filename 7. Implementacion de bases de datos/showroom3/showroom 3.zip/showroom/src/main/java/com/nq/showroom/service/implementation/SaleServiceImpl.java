package com.nq.showroom.service.implementation;

import com.nq.showroom.dto.messages.MessageDTO;
import com.nq.showroom.dto.request.PostSaleDTO;
import com.nq.showroom.dto.request.PutSaleDTO;
import com.nq.showroom.dto.response.ClothDTO;
import com.nq.showroom.dto.response.SaleDTO;
import com.nq.showroom.entity.Cloth;
import com.nq.showroom.entity.PaymentMethod;
import com.nq.showroom.entity.Sale;
import com.nq.showroom.exception.NotFoundException;
import com.nq.showroom.repository.IClothRepository;
import com.nq.showroom.repository.IPaymentMethodRepository;
import com.nq.showroom.repository.ISaleRepository;
import com.nq.showroom.service.ISaleService;
import com.nq.showroom.utils.MapperCustom;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class SaleServiceImpl implements ISaleService {

    private ISaleRepository saleRepository;
    private IClothRepository clothRepository;
    private IPaymentMethodRepository paymentMethodRepository;
    private ModelMapper mapper;
    private MapperCustom mapperCustom;

    public SaleServiceImpl(ISaleRepository saleRepository, IClothRepository clothRepository, IPaymentMethodRepository paymentMethodRepository, ModelMapper mapper, MapperCustom mapperCustom) {
        this.saleRepository = saleRepository;
        this.clothRepository = clothRepository;
        this.paymentMethodRepository = paymentMethodRepository;
        this.mapper = mapper;
        this.mapperCustom = mapperCustom;
    }

    @Override
    public MessageDTO createSale(PostSaleDTO saleDto) {
        Sale sale = new Sale();
        sale.setDate(saleDto.getDate());
        sale.setTotal(saleDto.getTotal());

        PaymentMethod paymentMethod = paymentMethodRepository.findById(saleDto.getPaymentMethod()).get();
        sale.setPaymentMethod(paymentMethod);
        sale.setClothes(new ArrayList<>());

        for (Long clothId : saleDto.getClothes()) {
            Cloth existingCloth = clothRepository.findById(clothId)
                    .orElseThrow(() -> new NotFoundException("Cloth not found with ID: " + clothId));

            if (existingCloth.getQuantity() == null) {
                existingCloth.setQuantity(0);
            }

            existingCloth.setQuantity(existingCloth.getQuantity() - 1);
            clothRepository.save(existingCloth);
            sale.getClothes().add(existingCloth);
        }

        saleRepository.save(sale);
        return new MessageDTO("Venta cargada con exito perri");
    }

    @Override
    public List<SaleDTO> findAll() {
        List<Sale> sales = saleRepository.findAll();
        List<SaleDTO> saleDTOList = mapperCustom.saleDTOList(sales);

        return saleDTOList;
    }

    @Override
    public SaleDTO findByNumber(Long numberSale) {
        Sale sale = saleRepository.findSaleByNumber(numberSale);
        return mapper.map(sale, SaleDTO.class);
    }

    @Override
    public MessageDTO updateSale(Long number, PutSaleDTO putSaleDTO) {
        Sale sale = saleRepository.findById(number)
                .orElseThrow(() -> new NotFoundException("Sale not found with number: " + number));

        sale.setNumber(number);
        sale.setDate(putSaleDTO.getDate());
        sale.setTotal(putSaleDTO.getTotal());
        PaymentMethod paymentMethod = paymentMethodRepository.findById(putSaleDTO.getPaymentMethod()).get();
        sale.setPaymentMethod(paymentMethod);

        List<Cloth> existingClothes = sale.getClothes();
        for (Cloth existingCloth : existingClothes) {
            existingCloth.setQuantity(existingCloth.getQuantity() + 1);
            clothRepository.save(existingCloth);
        }

        sale.setClothes(new ArrayList<>());

        for (Long clothId : putSaleDTO.getClothes()) {
            Cloth newCloth = clothRepository.findById(clothId)
                    .orElseThrow(() -> new NotFoundException("Cloth not found with ID: " + clothId));

            if (newCloth.getQuantity() == null) {
                newCloth.setQuantity(0);
            }

            newCloth.setQuantity(newCloth.getQuantity() - 1);
            clothRepository.save(newCloth);
            sale.getClothes().add(newCloth);
        }

        saleRepository.save(sale);
        return new MessageDTO("Venta actualizada con exito perri");
    }

    @Override
    public List<SaleDTO> findByDate(LocalDate date) {
        return mapperCustom.saleDTOList(saleRepository.findSalesByDate(date));
    }

    @Override
    public List<ClothDTO> getClothesBySale(Long number) {
        Sale foundSale = saleRepository.findSaleByNumber(number);
        SaleDTO saleDTO = mapper.map(foundSale, SaleDTO.class);
        return saleDTO.getClothes();
    }

    @Override
    public MessageDTO deleteSale(Long number) {
        Sale foundSale = saleRepository.findById(number).get();
        saleRepository.delete(foundSale);
        return new MessageDTO("Se eliminó correctamente.");
    }

}

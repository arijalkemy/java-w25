package com.nq.showroom.repository;

import com.nq.showroom.entity.Cloth;
import com.nq.showroom.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface ISaleRepository extends JpaRepository<Sale, Long> {
    List<Sale> findAll();
    Sale findSaleByNumber(Long number);
    List<Sale> findSalesByDate(LocalDate date);
    @Query("SELECT c FROM Cloth c JOIN c.sales s WHERE s.number = :number")
    List<Cloth> findClothsBySaleNumber(@Param("number") Long number);
}

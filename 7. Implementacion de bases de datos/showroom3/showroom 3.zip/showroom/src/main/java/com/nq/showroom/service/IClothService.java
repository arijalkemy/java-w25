package com.nq.showroom.service;
import com.nq.showroom.dto.response.ClothDTO;
import com.nq.showroom.dto.messages.MessageDTO;
import com.nq.showroom.dto.request.PostClothDTO;
import com.nq.showroom.dto.request.PutClothDTO;

import java.util.List;

public interface IClothService {
    List<ClothDTO> getAll(String name);
    MessageDTO createCloth(PostClothDTO clothDto);
    ClothDTO findClothByCode(Long code);
    MessageDTO updateClothByCode(Long code, PutClothDTO clothDto);
    MessageDTO deleteClothByCode(Long code);
    List<ClothDTO> findClothsBySize(String size);
}

package com.nq.showroom.controller;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.nq.showroom.dto.request.PostSaleDTO;
import com.nq.showroom.dto.request.PutSaleDTO;
import com.nq.showroom.dto.response.SaleDTO;
import com.nq.showroom.entity.Sale;
import com.nq.showroom.service.ISaleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/sale")
public class SaleController {
    private final ISaleService saleService;

    public SaleController(ISaleService saleService) {
        this.saleService = saleService;
    }

    // Crear una nueva venta. TODO OK
    @PostMapping("")
    public ResponseEntity<?> createSale(@RequestBody PostSaleDTO newSale) {
        return ResponseEntity.ok(saleService.createSale(newSale));
    }

    // Devolver todas las ventas TODO OK
    @GetMapping("")
    public ResponseEntity<?> getAllSales() {
        return ResponseEntity.ok(saleService.findAll());
    }

    // Devolver una venta en particular TODO OK
    @GetMapping("/{number}")
    public ResponseEntity<?> getSale(@PathVariable Long number) {
        return ResponseEntity.ok(saleService.findByNumber(number));
    }

    // Actualizar una venta en particular /api/sale/{number} TODO OK
    @PutMapping("/{number}")
    public ResponseEntity<?> updateSale(@PathVariable Long number, @RequestBody PutSaleDTO updatedSale) {
        return ResponseEntity.ok(saleService.updateSale(number, updatedSale));
    }

    // Eliminar una venta en particular /api/sale/{number] TODO OK
    @DeleteMapping("/{number}")
    public ResponseEntity<?> deleteSale(@PathVariable Long number) {
        saleService.deleteSale(number);
        return ResponseEntity.noContent().build();
    }

    // Traer todas las prendas de una determinada fecha TODO OK
    @GetMapping("/")
    public ResponseEntity<?> getClothesByDate(@RequestParam LocalDate date) {
        return ResponseEntity.ok(saleService.findByDate(date));
    }

    // Traer la lista completa de prendas de una determinada venta. TODO OK
    @GetMapping("/clothes/{number}")
    public ResponseEntity<?> getClothesBySale(@PathVariable Long number) {
        return ResponseEntity.ok(saleService.getClothesBySale(number));
    }
}

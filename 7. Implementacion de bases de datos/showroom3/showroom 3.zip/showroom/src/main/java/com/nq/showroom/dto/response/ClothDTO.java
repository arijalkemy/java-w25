package com.nq.showroom.dto.response;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ClothDTO {
    Long code;
    String name;
    String type;
    String brand;
    String color;
    String size;
    Integer quantity;
    Double sellingPrice;
}

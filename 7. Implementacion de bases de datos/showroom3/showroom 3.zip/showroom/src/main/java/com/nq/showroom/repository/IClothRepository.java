package com.nq.showroom.repository;

import com.nq.showroom.entity.Cloth;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface IClothRepository extends JpaRepository<Cloth, Long> {
    List<Cloth> findAll();
    List<Cloth> findClothsBySize(String size);
    List<Cloth> findClothsByNameContaining(String name);
}


package com.nq.showroom.controller;

import com.nq.showroom.dto.request.PostClothDTO;
import com.nq.showroom.dto.request.PutClothDTO;
import com.nq.showroom.service.IClothService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/clothes")
public class ClothController {

    private final IClothService clothService;

    public ClothController(IClothService clothService) {
        this.clothService = clothService;
    }

    // Crear una nueva prenda TODO OK
    @PostMapping("")
    public ResponseEntity<?> createCloth(@RequestBody PostClothDTO clothDto) {
        return new ResponseEntity<>(clothService.createCloth(clothDto), HttpStatus.CREATED);
    }

    // Devolver todas las prendas TODO OK
    // Buscar todas las prendas en cuyo nombre aparezca la palabra “remera”. TODO OK
    // No se tienen en cuenta ni mayúsculas ni minúsculas TODO OK
    @GetMapping("")
    public ResponseEntity<?> getAll(@RequestParam(required = false, defaultValue = "") String name) {
        return ResponseEntity.ok(clothService.getAll(name));
    }

    // Devolver una prenda en particular TODO OK
    @GetMapping("/{code}")
    public ResponseEntity<?> getByCode(@PathVariable Long code) {
        return ResponseEntity.ok(clothService.findClothByCode(code));
    }

    // Traer todas las prendas de un determinado talle TODO OK
    @GetMapping("/sizes/{size}")
    public ResponseEntity<?> getAllBySize(@PathVariable String size) {
        return ResponseEntity.ok(clothService.findClothsBySize(size));
    }

    // Actualizar una prenda en particular TODO OK
    @PutMapping("/{code}")
    public ResponseEntity<?> updateByCode(@PathVariable Long code,
                                          @RequestBody PutClothDTO cloth) {
        return ResponseEntity.ok(clothService.updateClothByCode(code, cloth));
    }

    // Eliminar una prenda en particular TODO OK
    @DeleteMapping("/{code}")
    public ResponseEntity<?> deleteByCode(@PathVariable Long code) {
        return ResponseEntity.ok(clothService.deleteClothByCode(code));
    }
}

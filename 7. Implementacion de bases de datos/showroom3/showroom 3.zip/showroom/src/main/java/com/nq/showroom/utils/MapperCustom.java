package com.nq.showroom.utils;

import com.nq.showroom.dto.response.ClothDTO;
import com.nq.showroom.dto.response.SaleDTO;
import com.nq.showroom.entity.Cloth;
import com.nq.showroom.entity.Sale;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class MapperCustom {
    public List<SaleDTO> saleDTOList(List<Sale> sales) {
        List<SaleDTO> saleDTOList = new ArrayList<>();
        for (Sale s : sales) {
            saleDTOList.add(
                    new SaleDTO(
                            s.getNumber(),
                            s.getDate(),
                            s.getTotal(),
                            s.getPaymentMethod().getDescription(),
                            clothDTOList(s.getClothes())
                    )
            );
        }
        return saleDTOList;
    }

    private List<ClothDTO> clothDTOList(List<Cloth> clothes) {
        List<ClothDTO> clothDTOList = new ArrayList<>();
        for (Cloth c : clothes) {
            clothDTOList.add(
                    new ClothDTO(
                            c.getCode(),
                            c.getName(),
                            c.getType(),
                            c.getBrand(),
                            c.getColor(),
                            c.getSize(),
                            c.getQuantity(),
                            c.getSellingPrice()
                    )
            );
        }
        return clothDTOList;
    }
}

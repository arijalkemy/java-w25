package com.nq.showroom.service;

import com.nq.showroom.dto.messages.MessageDTO;
import com.nq.showroom.dto.request.PostSaleDTO;
import com.nq.showroom.dto.request.PutSaleDTO;
import com.nq.showroom.dto.response.ClothDTO;
import com.nq.showroom.dto.response.SaleDTO;

import java.time.LocalDate;
import java.util.List;

public interface ISaleService {

    MessageDTO createSale(PostSaleDTO sale);

    List<SaleDTO> findAll();

    SaleDTO findByNumber(Long numberSale);

    MessageDTO updateSale(Long number, PutSaleDTO sale);

    List<SaleDTO> findByDate(LocalDate date);

    List<ClothDTO> getClothesBySale(Long number);

    MessageDTO deleteSale(Long number);
}

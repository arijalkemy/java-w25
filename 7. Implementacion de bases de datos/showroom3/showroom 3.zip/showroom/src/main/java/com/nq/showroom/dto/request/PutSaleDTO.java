package com.nq.showroom.dto.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.nq.showroom.dto.response.ClothDTO;
import com.nq.showroom.entity.PaymentMethod;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PutSaleDTO {
    @JsonFormat(pattern = "dd/MM/yyyy")
    LocalDate date;
    Double total;
    Long paymentMethod;
    List<Long> clothes;
}

package com.nq.showroom.service.implementation;

import com.nq.showroom.dto.messages.MessageDTO;
import com.nq.showroom.dto.request.PostClothDTO;
import com.nq.showroom.dto.request.PutClothDTO;
import com.nq.showroom.dto.response.ClothDTO;
import com.nq.showroom.entity.Cloth;
import com.nq.showroom.repository.IClothRepository;
import com.nq.showroom.service.IClothService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClothServiceImpl implements IClothService {

    IClothRepository repository;
    ModelMapper mapper;

    public ClothServiceImpl(IClothRepository repository, ModelMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    @Override
    public List<ClothDTO> getAll(String name) {
        if (name == null || name.isEmpty()) {
            return repository.findAll().stream().map(c -> mapper.map(c, ClothDTO.class)).toList();
        } else {
            return repository.findClothsByNameContaining(name).stream().map(c -> mapper.map(c, ClothDTO.class)).toList();
        }
    }

    @Override
    public MessageDTO createCloth(PostClothDTO clothDto) {
        Cloth cloth = mapper.map(clothDto, Cloth.class);
        repository.save(cloth);
        return new MessageDTO("Cloth created successfully!");
    }

    @Override
    public ClothDTO findClothByCode(Long code) {
        Cloth foundCloth = repository.findById(code).get();
        return mapper.map(foundCloth, ClothDTO.class);
    }

    @Override
    public MessageDTO updateClothByCode(Long code, PutClothDTO clothDto) {
        Cloth cloth = mapper.map(clothDto, Cloth.class);
        cloth.setCode(code);
        repository.save(cloth);
        return new MessageDTO("Cloth updates successfully!");
    }

    @Override
    public MessageDTO deleteClothByCode(Long code) {
        repository.deleteById(code);
        return new MessageDTO("Cloth was deleted successfully.");
    }

    @Override
    public List<ClothDTO> findClothsBySize(String size) {
        return repository.findClothsBySize(size).stream().map(c -> mapper.map(c, ClothDTO.class)).toList();
    }

}

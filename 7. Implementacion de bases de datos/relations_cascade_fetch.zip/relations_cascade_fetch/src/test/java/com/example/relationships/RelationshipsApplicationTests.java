package com.example.relationships;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelationshipsApplicationTests {

	@Test
	void contextLoads() {
	}

}

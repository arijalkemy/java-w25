package com.bootcamp.ejercicio_vehiculos_siniestros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioVehiculosSiniestrosApplicationTests {

	@Test
	void contextLoads() {
	}

}

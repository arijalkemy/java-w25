package com.bootcamp.ejercicio_vehiculos_siniestros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioVehiculosSiniestrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioVehiculosSiniestrosApplication.class, args);
	}

}

package com.bootcamp.ejercicio_vehiculos_siniestros.dto.response;

public class VehiculoDTO {
}

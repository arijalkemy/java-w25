package com.implementacionbd.ejercicio.service;

import com.implementacionbd.ejercicio.models.Vehiculo;

import java.util.List;

public interface IVehiculoService {

    List<Vehiculo> findAllVehicles();
}

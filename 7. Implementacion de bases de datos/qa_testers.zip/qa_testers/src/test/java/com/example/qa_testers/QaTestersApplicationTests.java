package com.example.qa_testers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QaTestersApplicationTests {

    @Test
    void contextLoads() {
    }

}

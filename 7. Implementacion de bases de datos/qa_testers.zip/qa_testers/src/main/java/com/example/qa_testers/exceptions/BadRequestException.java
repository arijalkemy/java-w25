package com.example.qa_testers.exceptions;

public class BadRequestException extends RuntimeException{
    public BadRequestException(String message){ super(message); }
}

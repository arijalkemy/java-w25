package com.example.qa_testers.dtos;

public record ExceptionDto (String message){
}

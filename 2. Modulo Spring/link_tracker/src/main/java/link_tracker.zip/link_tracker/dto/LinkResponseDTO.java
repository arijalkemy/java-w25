package link_tracker.dto;

public class LinkResponseDTO {

    private int linkId;

    public LinkResponseDTO(int linkId) {
        this.linkId = linkId;
    }
}

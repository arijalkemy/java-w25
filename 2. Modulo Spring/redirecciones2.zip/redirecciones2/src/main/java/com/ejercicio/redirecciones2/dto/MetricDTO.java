package com.ejercicio.redirecciones2.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class MetricDTO {
    private Integer id;
    private Integer redirectCounter;
}

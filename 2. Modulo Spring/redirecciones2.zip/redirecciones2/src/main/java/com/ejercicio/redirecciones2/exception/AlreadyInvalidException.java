package com.ejercicio.redirecciones2.exception;

public class AlreadyInvalidException extends  RuntimeException{
    public AlreadyInvalidException(String message){
        super(message);

    }
}

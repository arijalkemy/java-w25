package com.ejercicio.redirecciones2.exception;

public class AlreadyExistsException extends RuntimeException{
    public AlreadyExistsException(String message){
        super(message);

    }
}
